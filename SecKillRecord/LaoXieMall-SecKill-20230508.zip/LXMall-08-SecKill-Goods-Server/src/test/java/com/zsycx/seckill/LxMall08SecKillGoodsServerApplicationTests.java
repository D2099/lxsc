package com.zsycx.seckill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LxMall08SecKillGoodsServerApplicationTests {

    @Test
    void contextLoads() {
    }

}

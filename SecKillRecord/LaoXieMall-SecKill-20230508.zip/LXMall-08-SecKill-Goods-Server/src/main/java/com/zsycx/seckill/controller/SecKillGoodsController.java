package com.zsycx.seckill.controller;

import com.zsycx.commons.Code;
import com.zsycx.commons.JsonResult;
import com.zsycx.seckill.domain.Goods;
import com.zsycx.seckill.service.GoodsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @ClassName: SecKillGoodsController
 * @Description: TODO
 * @E-mail: 209733813@qq.com
 */
@RestController
@CrossOrigin
public class SecKillGoodsController {

    @Resource
    private GoodsService goodsService;
    
    @RequestMapping("/getGoodsList")
    public JsonResult<List<Goods>> getGoodsList() {

        List<Goods> goodsJsonResultList = goodsService.getGoodsList();

        return new JsonResult<>(Code.OK, goodsJsonResultList);
    }

    @RequestMapping("/secKill")
    public Object secKill(Long goodsId) {
        // 模拟用户ID
        Long uid = 8L;

        Integer result = goodsService.getSecKill(goodsId, uid);

        return new JsonResult<>(Code.OK, "");
    }
}

package com.zsycx.seckill.service.impl;

import com.zsycx.seckill.commons.Constants;
import com.zsycx.seckill.domain.Goods;
import com.zsycx.seckill.mapper.GoodsMapper;
import com.zsycx.seckill.service.GoodsService;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @ClassName: GoodsServiceImpl
 * @Description: TODO
 * @E-mail: 209733813@qq.com
 */
@Service
public class GoodsServiceImpl implements GoodsService {

    @Resource
    private GoodsMapper goodsMapper;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public List<Goods> getGoodsList() {

        List<Goods> goodsList = goodsMapper.selectAll();

        return goodsList;
    }

    /**
     * 进行秒杀操作
     * @param goodsId
     * @param uid
     * @return
     * 返回 0 表示下单成功
     * 返回 1 表示秒杀未开始
     * 返回 2 表示秒杀已结束
     * 返回 3 表示没有库存
     * 返回 4 表示已经购买
     */
    @Override
    public Integer getSecKill(Long goodsId, Long uid) {

        System.out.println("GoodsServiceImpl.java:33:goodsId:" + goodsId);
        System.out.println("GoodsServiceImpl.java:34:uid:" + uid);

        Map<Object, Object> entries = stringRedisTemplate.opsForHash().entries(Constants.SEC_KILL_GOODS_STORE + goodsId);

        long startTime = Long.parseLong(entries.get("startTime").toString());
        long endTime = Long.parseLong(entries.get("endTime").toString());
        // 获取系统当前时间
        long currentTimeMillis = System.currentTimeMillis();
        // 判断是否是秒杀时间
        if (startTime > currentTimeMillis) {
            return 1;
        } else if (endTime < currentTimeMillis) {
            return 2;
        }

        // 进行库存减少操作
        stringRedisTemplate.execute(new SessionCallback<Object>() {
            @Override
            public <K, V> Object execute(RedisOperations<K, V> redisOperations) throws DataAccessException {

                List keys = new ArrayList();
                keys.add(Constants.SEC_KILL_GOODS_STORE + goodsId);
                keys.add(Constants.SEC_KILL_PURCHASE_LIMITS + goodsId + ":" + uid);
                // 监控 List 集合中的 key
                redisOperations.watch(keys);

                // 获取库存
                Integer storeStr = (Integer) redisOperations.opsForHash().get((K) (Constants.SEC_KILL_GOODS_STORE + goodsId), "store");
                // 判断是否有库存
                if (storeStr != null && storeStr <= 0) {
                    return 3;
                }

                // 获取购买记录
                String purchaseLimits = (String) redisOperations.opsForValue().get(Constants.SEC_KILL_PURCHASE_LIMITS + goodsId + ":" + uid);
                // 判断是否已经购买
                if (purchaseLimits != null) {
                    return 4;
                }
                // 如果代码执行到这里，表示库存够用，并且没有购买
                // 开启事务
                redisOperations.multi();
                // 进行库存更新
                redisOperations.opsForHash().put((K) (Constants.SEC_KILL_GOODS_STORE + goodsId), "store",storeStr - 1);
                // 添加购买记录
                redisOperations.opsForValue().set((K) (Constants.SEC_KILL_PURCHASE_LIMITS + goodsId + ":" + uid), (V) "1");
                // 提交事务，如果返回的集合长度不为 0 表示购买成功
                return redisOperations.exec();
            }
        });

        return 0;
    }
}
